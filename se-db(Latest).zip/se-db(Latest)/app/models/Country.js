// Get the functions in the db.js file to use
const db = require('./../services/db');


class Country {
    // country Code
    Code;
    
    // country name
    Name;
    
    // country continent
    Continent;
    
    // Country Region
    Region;
 
    // Country population
    Population;

   
    constructor(Code) {
    this.Code = Code;
    }
   
    async getCountryName() {
        if (typeof this.Name !== 'string') {
            var sql = "SELECT * from country where Code = ?"
            const results = await db.query(sql, [this.Code]);
            this.Name = results[0].Name;
        }
    }

    async getCountryContinent() {
        if (typeof this.Continent !== 'string') {
            var sql = "SELECT * from country where Code = ?"
            const results = await db.query(sql, [this.Code]);
            this.Continent = results[0].Continent;
        }
    }

    async getCountryRegion() {
        if (typeof this.Region !== 'string') {
            var sql = "SELECT * from country where Code = ?"
            const results = await db.query(sql, [this.Code]);
            this.Region = results[0].Region;
        }
    }

    async getCountryPopulation() {
        if (typeof this.Population !== 'string') {
            var sql = "SELECT * from country where Code = ?"
            const results = await db.query(sql, [this.Code]);
            this.Population = results[0].Population;
        }
    }

   
}

module.exports = {
    Country
   }