// Get the functions in the db.js file to use
const db = require('../services/db');


class CountryLanguage {
    // Country Code
    CountryCode;
    
    // Language
    Language;

    //Is Official
    IsOfficial;


    //Percentage
    Percentage;


    constructor(CountryCode) {
    this.CountryCode = CountryCode;
    }
   
    async getCountryLanguage() {
        if (typeof this.Language !== 'string') {
            var sql = "SELECT * from countrylanguage where CountryCode = ?"
            const results = await db.query(sql, [this.CountryCode]);
            this.Language = results[0].Language;
        }
    }

    async getIsOfficial() {
        if (typeof this.IsOfficial !== 'string') {
            var sql = "SELECT * from countrylanguage where CountryCode = ?"
            const results = await db.query(sql, [this.CountryCode]);
            this.IsOfficial = results[0].IsOfficial;
        }
    }

    async getPercentage() {
        if (typeof this.Percentage !== 'string') {
            var sql = "SELECT * from countrylanguage where CountryCode = ?"
            const results = await db.query(sql, [this.CountryCode]);
            this.Percentage = results[0].Percentage;
        }
    }

}

module.exports = {
    CountryLanguage
   }