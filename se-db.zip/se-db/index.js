"use strict";

// Include the app.js file.
// This will run the code.
console.log("index.js started");

console.log("entrypoint");
const app = require("./app/app.js");