// Get the functions in the db.js file to use
const db = require('./../services/db');


class City {
    // City ID
    ID;
    
    // city name
    Name;

    CountryCode;

    District;

    Population;
   
    constructor(ID) {
    this.ID = ID;
    }
   
    async getCityName() {
        if (typeof this.Name !== 'string') {
            var sql = "SELECT * from city where ID = ?"
            const results = await db.query(sql, [this.ID]);
            this.Name = results[0].Name;
        }
    }

    async getCityCountryCode() {
        if (typeof this.CountryCode !== 'string') {
            var sql = "SELECT * from city where ID = ?"
            const results = await db.query(sql, [this.ID]);
            this.CountryCode = results[0].CountryCode;
        }
    }

    async getCityDistrict() {
        if (typeof this.District !== 'string') {
            var sql = "SELECT * from city where ID = ?"
            const results = await db.query(sql, [this.ID]);
            this.District = results[0].District;
        }
    }


    async getCityPopulation() {
        if (typeof this.Population !== 'string') {
            var sql = "SELECT * from city where ID = ?"
            const results = await db.query(sql, [this.ID]);
            this.Population = results[0].Population;
        }
    }




   
}

module.exports = {
    City
   }