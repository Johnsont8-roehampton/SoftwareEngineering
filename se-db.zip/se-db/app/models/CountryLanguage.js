// Get the functions in the db.js file to use
const db = require('../services/db');


class CountryLanguage {
    // Country Code
    CountryCode;
    
    // Language
    Language;
       
    constructor(CountryCode) {
    this.CountryCode = CountryCode;
    }
   
    async getCountryLanguage() {
        if (typeof this.Language !== 'string') {
            var sql = "SELECT * from countrylanguage where CountryCode = ?"
            const results = await db.query(sql, [this.CountryCode]);
            this.Language = results[0].Language;
        }
    }

}

module.exports = {
    CountryLanguage
   }