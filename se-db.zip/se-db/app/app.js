console.log("app.js started");

// Import express.js
const express = require("express");
console.log("Importing express")

const mysql = require('mysql2');
console.log("Importing mysql2")

const pug = require('pug');  //https://pugjs.org/api/getting-started.html
console.log("Importing pug")


// Create express app
var app = express();

// Add static files location
app.use(express.static("static"));


// Use the Pug templating engine
app.set('view engine', 'pug');
app.set('views', './app/views');
console.log("Using Pug templating engine")


// Get the functions in the db.js file to use
const db = require('./services/db');

// Get the models
const { City } = require("./models/City");
const { Country } = require("./models/Country");
const { CountryLanguage } = require("./models/CountryLanguage");



// Start server on port 3000
app.listen(3000,function(){
    console.log('phpmyadmin running at http://localhost:8081/');
    console.log(`Server running at http://127.0.0.1:3000/`);
});

// Create a route for root - /
app.get("/", function(req, res) {
    //res.send("Hello world! - se-db");
    
    //Using PUG
    //res.render("index");  //pug
    //res.render("index", {'title':'My index page', 'heading':'My heading'});

    // Set up an array of data
    var test_data = ['one', 'two', 'three', 'four'];
    // Send the array through to the template as a variable called data
    res.render("index-1", {'title':'My index page', 'heading':'My heading', 'data':test_data});
});


// Create a route for testing the db table Modules
app.get("/all-countryLanguage-formatted", function(req, res) {
    // Prepare an SQL query that will return all rows from the Modules
    var sql = 'select * from countryLanguage';
   
    // Use the db.query() function from services/db.js to send our query
    // We need the result to proceed, but
    // we are not inside an async function we cannot use await keyword here.
    // So we use a .then() block to ensure that we wait until the
    // promise returned by the async function is resolved before we proceed
    
    //var output = '<table border = "1px">';
    db.query(sql).then(results => {
        res.render('all-countryLanguage', {data:results});
    });
});



///====================Single-COUNTRY-Language==========================//

app.get("/single-country-language/:CountryCode",async function (req, res) {
    var countryLanguageCode = req.params.CountryCode;
    // Create a country class with the ID passed
    var countryLanguage = new CountryLanguage(countryLanguageCode);
    //Get Country Name
    await countryLanguage.getCountryLanguage();

    console.log(countryLanguage);
    //res.send(city);
    res.render('countryLanguage', {countryLanguage:countryLanguage});

});




///====================COUNTRIES==========================//

// Create a route for testing the db table Modules
app.get("/all-countries-formatted", function(req, res) {
    // Prepare an SQL query that will return all rows from the Modules
    var sql = 'select * from country';
   
    // Use the db.query() function from services/db.js to send our query
    // We need the result to proceed, but
    // we are not inside an async function we cannot use await keyword here.
    // So we use a .then() block to ensure that we wait until the
    // promise returned by the async function is resolved before we proceed
    
    //var output = '<table border = "1px">';
    db.query(sql).then(results => {
        res.render('all-countries', {data:results});
    });
});

//=============Single-Country===============//

app.get("/single-country/:Code",async function (req, res) {
    var countryCode = req.params.Code;
    // Create a country class with the ID passed
    var country = new Country(countryCode);
    //Get Country Name
    await country.getCountryName();

    //Get country Continent
    await country.getCountryContinent();
    
    //Get country Region
    await country.getCountryRegion();

    //Get country Population
    await country.getCountryPopulation();


    console.log(country);
    //res.send(city);
    res.render('Country', {country:country});

});

///====================CITIES===========================//

// Create a route for testing the db table Modules
app.get("/all-cities", function(req, res) {
    // Prepare an SQL query that will return all rows from the Modules
    var sql = 'select * from city';
   
    // Use the db.query() function from services/db.js to send our query
    // We need the result to proceed, but
    // we are not inside an async function we cannot use await keyword here.
    // So we use a .then() block to ensure that we wait until the
    // promise returned by the async function is resolved before we proceed
    db.query(sql).then(results => {
        // Take a peek in the console
        console.log(results);
        
        // Send to the web pate
        res.send(results)
    });
});

// Create a route for testing the db table Modules
app.get("/all-cities-formatted", function(req, res) {
    // Prepare an SQL query that will return all rows from the Modules
    var sql = 'select * from city';
   
    // Use the db.query() function from services/db.js to send our query
    // We need the result to proceed, but
    // we are not inside an async function we cannot use await keyword here.
    // So we use a .then() block to ensure that we wait until the
    // promise returned by the async function is resolved before we proceed
    
    //var output = '<table border = "1px">';
    db.query(sql).then(results => {
        res.render('all-cities', {data:results});
    });
});


//=============Single-City===============//

app.get("/single-city/:ID",async function (req, res) {
    var cityID = req.params.ID;
    // Create a city class with the ID passed
    var city = new City(cityID);


    await city.getCityName();

    //Get city CountryCode
    await city.getCityCountryCode()

    //Get city District
    await city.getCityDistrict()

    //Get city Population
    await city.getCityPopulation()     



    console.log(city);
    //res.send(city);
    res.render('City', {city:city});

});

app.get("/Login", function(req, res) {
    
    
    res.render("Login")
});

app.get("/Register", function(req, res) {
    
    res.render("Register");
});




// Create a route for /goodbye
// Responds to a 'GET' request
app.get("/goodbye", function(req, res) {
    res.send("Goodbye world!");
});

// Create a dynamic route for /hello/<name>, where name is any value provided by user
// At the end of the URL
// Responds to a 'GET' request
app.get("/hello/:name", function(req, res) {
    // req.params contains any parameters in the request
    // We can examine it in the console for debugging purposes
    console.log(req.params);
    //  Retrieve the 'name' parameter and use it in a dynamically generated page
    res.send("Hello " + req.params.name);
});